package StudentManagementSystem;

import java.util.Scanner;

public class Student {

    private String Firstname;
    private String Lastname;
    private int Year;
    private String Studentid;
    private String Courses = "";
    private double TuitionBalance = 0;
    private static double Coursecost = 600;
    private static int id = 1000;


    // Constructor; props user to enter student name and year
    public Student() {
        Scanner in = new Scanner(System.in);
        System.out.print("\nEnter Student First Name: ");
        this.Firstname = in.nextLine();

        System.out.print("Enter Student Last Name: ");
        this.Lastname = in.nextLine();

        System.out.print("Enter Student School Year:\nEnter 1 for Year 7\nEnter 2 for Year 8\nEnter 3 for Year 9\nEnter 4 for Year 10\nEnter 5 for Year 11\n");
        this.Year = in.nextInt();

        setStudentID();


    }

    // Generate an ID
    private void setStudentID() {
        // grade level + ID
        id++;
        this.Studentid = Year + "" + id;


    }
    // Enroll in courses

    public void enroll() {
        // get inside a loop, user hits Q
        do {
            System.out.print("Enter course(s) to enroll ('Q' or 'q' to quit): ");
            Scanner in = new Scanner(System.in);
            String Course = in.nextLine();
            if (!Course.matches("Q|q")) {
                Courses = Courses +"\n" + Course;
                TuitionBalance = TuitionBalance + Coursecost;

            } else {
                break;
            }
        } while (1 != 0);

    }

    // View balance
    public void viewbalance() {
        System.out.println("Your current balance is: £" + TuitionBalance);
    }

    // Pay tuition
    public void payTuition() {
        viewbalance();
        System.out.print("Enter the amount you would like to pay £: ");
        Scanner in = new Scanner(System.in);
        double payment = in.nextDouble();
        TuitionBalance = TuitionBalance - payment;
        System.out.println("Thank you for your payment of £" + payment);
        viewbalance();

    }
    // Show status
    public String showInfo() {
        return  "\nStudent Information" + "\n___________________" +
                "\nName: " + Firstname + " " + Lastname +
                "\nSchool Year: " + Year +
                "\nStudentId: " + Studentid +
                "\nCourses Enrolled: " + Courses +
                "\nBalance: £" + TuitionBalance;
    }
}
