package StudentManagementSystem;

import java.util.Scanner;

public class StudentMainMethod {

    public static void main(String[] args) {


        // ask how many students we want to add
        System.out.print("Enter the number of students you want to enroll:");
        Scanner in = new Scanner(System.in);
        int numberofStudent = in.nextInt();
        Student[] students = new Student[numberofStudent];

        // create n number of students
        int i = 0;
        while ( i< numberofStudent){
            students[i] = new Student();
            students[i].enroll();
            students[i].payTuition();
            i++;}

        int n = 0;
        while ( n< numberofStudent){
            System.out.println(students[n].showInfo());
            n++;}

    }
}
